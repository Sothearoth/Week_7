<?php
$string = "emocleW ot PHP";
echo"Reverse string is : ".strrev ( $string );  

?>