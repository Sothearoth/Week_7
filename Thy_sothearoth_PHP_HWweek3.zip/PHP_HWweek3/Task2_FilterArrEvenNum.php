<?php
$arr = [2,3,4,6,7,9,11,20];
for ($i=0; $i < count($arr); $i++){    
    if ($arr[$i] % 2 == 0) {
        echo "Even numbers is", " ", $arr[$i], "\n";
      }
    
    }  
?>