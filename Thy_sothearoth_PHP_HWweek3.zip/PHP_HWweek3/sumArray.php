<?php
function sumInfitNum(...$nums)
{
    $sum = 0;
    foreach ($nums as $n) {
        $sum += $n;
    }
    return $sum;
}

echo sumInfitNum(2, 3);
echo sumInfitNum(2, 3,4);
echo sumInfitNum(2, 3,4,5);


?>