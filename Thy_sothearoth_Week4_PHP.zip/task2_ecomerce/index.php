<?php

require_once(__DIR__ . '/model/aba.php');
require_once(__DIR__ . '/model/wing.php');
require_once(__DIR__ . '/model/pipay.php');

echo '<h1>Sample Sale Data</h1>';

// Square => 5
// Rectangle => 3
// Triangle => 2

$data = [
    new aba(5,1),
    new wing(3,2),
    new aba(4,1),
    new aba(5,1),
    new pipay(6,1),
    new aba(10,1),
    new wing(15,1),
    new wing(2,1),

];

 
function renderDisplayData($data)
{
    $str = '<table border="1"><tr><th>Item</th><th>Price</th><th>Quantity</th><th>Method</th><th>Total</th></tr>';
    foreach ($data as $data) {
        $str .= '<tr><td>'.$data->getItem().'</td><td>'.$data->getPrice().'</td><td>'.$data->getQty().'</td><td>'.$data->getMethod().'</td><td>'.$data->getTotal();
    }
    $str .= '</table>';

    return $str;
}

echo '<p>Here are sample sales data</p>';

echo renderDisplayData($data);


?>