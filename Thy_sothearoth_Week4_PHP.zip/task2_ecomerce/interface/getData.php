<?php
interface getData
{
    public function getItem();
    public function getPrice();
    public function getQty();
    public function getMethod();
    public function getTotal();





}