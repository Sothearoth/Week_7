<?php
require_once(__DIR__ . '/../interface/getData.php');

class pipay implements getData{
    public function __construct(
        protected float $price,
        protected float $qty,
       
        
    ) {}
    
    public function getItem(){
        
    }
    public function getTotal(){
        return $this->price * $this->qty;
    }

    public function getPrice(){
        return $this->price ;
      }
      public function getQty(){
        return $this->qty;
      }

    public function getMethod(){
       return 'PIPAY';
    }


    



}

